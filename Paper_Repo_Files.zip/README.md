# llm-agent-frameworks-pypi-study

Release Cadence, Dependency Footprint and Version-Constraint Practices of Open-Source LLM Agent Frameworks: A Reproducible Snapshot of the Python Ecosystem

Author: Syed Muhammad Taqi Naqvi (Independent Researcher, Pakistan)

- `Naqvi_Agent_Frameworks_PyPI_Study.pdf` – full paper
- `Supplementary_Files.zip` – dataset, raw PyPI metadata snapshot (13 Nov 2026), scripts (`collect.py`, `metrics.py`, `analyze.py`), results

Reproduce offline: unzip the raw metadata, then `python3 metrics.py && python3 analyze.py`.
Licence: CC BY 4.0.
